-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2021 at 07:34 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `apply_job_post`
--

CREATE TABLE `apply_job_post` (
  `id_apply` int(11) NOT NULL,
  `id_jobpost` int(11) NOT NULL,
  `id_company` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `apply_job_post`
--

INSERT INTO `apply_job_post` (`id_apply`, `id_jobpost`, `id_company`, `id_user`, `status`) VALUES
(1, 2, 1, 1, 2),
(2, 3, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `state_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `state_id`) VALUES
(1, 'Bombuflat', 1),
(2, 'Garacharma', 1),
(3, 'Port Blair', 1),
(4, 'Rangat', 1),
(5, 'Addanki', 2),
(6, 'Adivivaram', 2),
(7, 'Adoni', 2),
(8, 'Aganampudi', 2),
(9, 'Ajjaram', 2),
(10, 'Akividu', 2);

-- --------------------------------------------------------

--
-- Table structure for table `job_post`
--

CREATE TABLE `job_post` (
  `id_jobpost` int(11) NOT NULL,
  `id_company` int(11) NOT NULL,
  `jobtitle` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `minimumsalary` varchar(255) NOT NULL,
  `maximumsalary` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_post`
--

INSERT INTO `job_post` (`id_jobpost`, `id_company`, `jobtitle`, `description`, `minimumsalary`, `maximumsalary`, `experience`, `qualification`, `createdat`) VALUES
(1, 1, 'Job Post 1', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666; font-size: 15px; font-family: avenir; font-weight: 200;\\\">This demo includes our most popular Premium Plugins: <a href=\\\"powerpaste\\\">PowerPaste</a>, <a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>, <a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>, <a href=\\\"link-checker/\\\">Link Checker</a>, <a href=\\\"accessibility-checker\\\">Accessibility Checker</a>, <a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a> &amp; <a href=\\\"http://www.moxiemanager.com\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666; font-size: 15px; font-family: avenir; font-weight: 200;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666; font-size: 15px; font-family: avenir; font-weight: 200;\\\">Used on more than 100 million websites and with upward of 70% market share*, <br /> TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666; font-size: 15px; font-family: avenir; font-weight: 200;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br /> * Market share stats, Wappalyzer, 2021.</p>\\r\\n<p><!-- x-tinymce/html --></p>\\r\\n<p>&nbsp;</p>', '25000', '50000', '5', 'Graduate', '2017-09-28 13:18:53'),
(2, 1, 'Job Post 2', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">This demo includes our most popular Premium Plugins:&nbsp;<a href=\\\"powerpaste\\\">PowerPaste</a>,&nbsp;<a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>,&nbsp;<a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>,&nbsp;<a href=\\\"link-checker/\\\">Link Checker</a>,&nbsp;<a href=\\\"accessibility-checker\\\">Accessibility Checker</a>,&nbsp;<a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a>&nbsp;&amp;&nbsp;<a href=\\\"http://www.moxiemanager.com/\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">Used on more than 100 million websites and with upward of 70% market share*,&nbsp;<br />TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br />* Market share stats, Wappalyzer, 2021.</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>&nbsp;</p>', '35000', '6000000', '2', 'Graduate', '2021-09-28 13:19:19'),
(3, 1, 'Job Post 3', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">This demo includes our most popular Premium Plugins:&nbsp;<a href=\\\"powerpaste\\\">PowerPaste</a>,&nbsp;<a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>,&nbsp;<a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>,&nbsp;<a href=\\\"link-checker/\\\">Link Checker</a>,&nbsp;<a href=\\\"accessibility-checker\\\">Accessibility Checker</a>,&nbsp;<a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a>&nbsp;&amp;&nbsp;<a href=\\\"http://www.moxiemanager.com/\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">Used on more than 100 million websites and with upward of 70% market share*,&nbsp;<br />TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br />* Market share stats, Wappalyzer, 2021.</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>&nbsp;</p>', '35000', '6000000', '2', 'Graduate', '2021-09-28 13:19:19'),
(4, 1, 'Job Post 4', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">This demo includes our most popular Premium Plugins:&nbsp;<a href=\\\"powerpaste\\\">PowerPaste</a>,&nbsp;<a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>,&nbsp;<a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>,&nbsp;<a href=\\\"link-checker/\\\">Link Checker</a>,&nbsp;<a href=\\\"accessibility-checker\\\">Accessibility Checker</a>,&nbsp;<a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a>&nbsp;&amp;&nbsp;<a href=\\\"http://www.moxiemanager.com/\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">Used on more than 100 million websites and with upward of 70% market share*,&nbsp;<br />TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br />* Market share stats, Wappalyzer, 2021.</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>&nbsp;</p>', '35000', '6000000', '2', 'Graduate', '2021-09-28 13:19:19'),
(5, 1, 'Job Post 5', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">This demo includes our most popular Premium Plugins:&nbsp;<a href=\\\"powerpaste\\\">PowerPaste</a>,&nbsp;<a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>,&nbsp;<a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>,&nbsp;<a href=\\\"link-checker/\\\">Link Checker</a>,&nbsp;<a href=\\\"accessibility-checker\\\">Accessibility Checker</a>,&nbsp;<a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a>&nbsp;&amp;&nbsp;<a href=\\\"http://www.moxiemanager.com/\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">Used on more than 100 million websites and with upward of 70% market share*,&nbsp;<br />TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br />* Market share stats, Wappalyzer, 2021.</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>&nbsp;</p>', '35000', '6000000', '2', 'Graduate', '2021-09-28 13:19:19'),
(6, 1, 'Job Post 6', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">This demo includes our most popular Premium Plugins:&nbsp;<a href=\\\"powerpaste\\\">PowerPaste</a>,&nbsp;<a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>,&nbsp;<a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>,&nbsp;<a href=\\\"link-checker/\\\">Link Checker</a>,&nbsp;<a href=\\\"accessibility-checker\\\">Accessibility Checker</a>,&nbsp;<a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a>&nbsp;&amp;&nbsp;<a href=\\\"http://www.moxiemanager.com/\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">Used on more than 100 million websites and with upward of 70% market share*,&nbsp;<br />TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br />* Market share stats, Wappalyzer, 2021.</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>&nbsp;</p>', '35000', '6000000', '2', 'Graduate', '2021-09-28 13:19:19'),
(7, 1, 'Job Post 7', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">This demo includes our most popular Premium Plugins:&nbsp;<a href=\\\"powerpaste\\\">PowerPaste</a>,&nbsp;<a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>,&nbsp;<a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>,&nbsp;<a href=\\\"link-checker/\\\">Link Checker</a>,&nbsp;<a href=\\\"accessibility-checker\\\">Accessibility Checker</a>,&nbsp;<a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a>&nbsp;&amp;&nbsp;<a href=\\\"http://www.moxiemanager.com/\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">Used on more than 100 million websites and with upward of 70% market share*,&nbsp;<br />TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br />* Market share stats, Wappalyzer, 2021.</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>&nbsp;</p>', '35000', '6000000', '2', 'Graduate', '2021-09-28 13:19:19'),
(8, 1, 'Job Post 8', '<p>&nbsp;</p>\\r\\n<p style=\\\"text-align: center; font-size: 15px;\\\"><img src=\\\"images/glyph-tinymce@2x.png\\\" alt=\\\"TinyMCE\\\" width=\\\"77\\\" height=\\\"70\\\" /></p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">This demo includes our most popular Premium Plugins:&nbsp;<a href=\\\"powerpaste\\\">PowerPaste</a>,&nbsp;<a href=\\\"enhanced-media-embed/\\\">Enhanced Media Embed</a>,&nbsp;<a href=\\\"advanced-code-editor/\\\">Advanced Code Editor</a>,&nbsp;<a href=\\\"link-checker/\\\">Link Checker</a>,&nbsp;<a href=\\\"accessibility-checker\\\">Accessibility Checker</a>,&nbsp;<a href=\\\"spell-checker-pro\\\">Spell Checker Pro</a>&nbsp;&amp;&nbsp;<a href=\\\"http://www.moxiemanager.com/\\\">MoxieManager</a>.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">TinyMCE is the world\\\'s #1 web-based HTML WYSIWYG editor control.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\">Used on more than 100 million websites and with upward of 70% market share*,&nbsp;<br />TinyMCE is the first and only choice for your next project.</p>\\r\\n<p style=\\\"text-align: center; color: #666666; font-size: 15px; font-family: avenir;\\\"><em>TinyMCE enables you to convert HTML textarea fields or other HTML elements to editor instances.</em><br />* Market share stats, Wappalyzer, 2021.</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>&nbsp;</p>', '35000', '6000000', '2', 'Graduate', '2021-09-28 13:19:19');

-- --------------------------------------------------------

--
-- Table structure for table `mailbox`
--

CREATE TABLE `mailbox` (
  `id_mailbox` int(11) NOT NULL,
  `id_fromuser` int(11) NOT NULL,
  `fromuser` varchar(255) NOT NULL,
  `id_touser` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reply_mailbox`
--

CREATE TABLE `reply_mailbox` (
  `id_reply` int(11) NOT NULL,
  `id_mailbox` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `usertype` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `country_id`) VALUES
(1, 'Andaman and Nicobar Islands', 101),
(2, 'Andhra Pradesh', 101),
(3, 'Arunachal Pradesh', 101),
(4, 'Assam', 101),
(5, 'Bihar', 101),
(6, 'Chandigarh', 101),
(7, 'Chhattisgarh', 101),
(8, 'Dadra and Nagar Haveli', 101),
(9, 'Daman and Diu', 101),
(10, 'Delhi', 101),
(11, 'Goa', 101),
(12, 'Gujarat', 101);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `contactno` varchar(255) DEFAULT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `stream` varchar(255) DEFAULT NULL,
  `passingyear` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `resume` varchar(255) DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `aboutme` text,
  `skills` text,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- ALTER TABLE `users`
--   MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `firstname`, `lastname`, `email`, `password`, `address`, `city`, `state`, `contactno`, `qualification`, `stream`, `passingyear`, `dob`, `age`, `designation`, `resume`, `hash`, `active`, `aboutme`, `skills`) VALUES
(1, 'Hello', 'World', 'test@test.com', 'ZTM4OGYwMmY3NTBlNjVlYmJhOTVhYjk0OTNjZGEwMWU=', 'Ipsum ut deserunt reprehenderit mollitia Nam et dolore aute asperiores tempor numquam ipsa minus ut aute amet', 'ABC', 'XYZ', '1234567890', 'ABC', 'XYZ', '1984-05-28', '2005-01-13', '12', 'Ipsa illo voluptates vel maiores enim earum sunt', '59ccdd17a18df.pdf', 'e62f5f796f08347890abe4f8ecf38409', 1, 'Dolores ut quis ut mollit', 'PHP, Javascript, Web Development');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `apply_job_post`
--
ALTER TABLE `apply_job_post`
  ADD PRIMARY KEY (`id_apply`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id_company`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_post`
--
ALTER TABLE `job_post`
  ADD PRIMARY KEY (`id_jobpost`);

--
-- Indexes for table `mailbox`
--
ALTER TABLE `mailbox`
  ADD PRIMARY KEY (`id_mailbox`);

--
-- Indexes for table `reply_mailbox`
--
ALTER TABLE `reply_mailbox`
  ADD PRIMARY KEY (`id_reply`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `apply_job_post`
--
ALTER TABLE `apply_job_post`
  MODIFY `id_apply` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48315;
--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id_company` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;
--
-- AUTO_INCREMENT for table `job_post`
--
ALTER TABLE `job_post`
  MODIFY `id_jobpost` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `mailbox`
--
ALTER TABLE `mailbox`
  MODIFY `id_mailbox` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reply_mailbox`
--
ALTER TABLE `reply_mailbox`
  MODIFY `id_reply` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4121;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
