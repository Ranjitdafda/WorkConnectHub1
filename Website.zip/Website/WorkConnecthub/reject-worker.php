<?php

session_start();

if(empty($_SESSION['id_admin'])) {
	header("Location: index.php");
	exit();
}


require_once("../db.php");

if(isset($_GET)) {

	//Delete worker using id and redirect
	$sql = "UPDATE worker SET active='0' WHERE id_worker='$_GET[id]'";
	if($conn->query($sql)) {
		header("Location: workers.php");
		exit();
	} else {
		echo "Error";
	}
}