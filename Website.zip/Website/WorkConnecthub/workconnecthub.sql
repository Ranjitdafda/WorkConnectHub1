-- Create the 'admin' table
CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Insert data into the 'admin' table
INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', '12345'),
(2, 'harshil@gmail.com', '12345'),
(3, 'ranjit@gmail.com', '12345');

-- Create the 'worker' table
CREATE TABLE `worker` (
  `id_worker` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `workname` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `adharnumber` bigint(12) NOT NULL,
  `profilephoto` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `aboutme` varchar(255) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id_worker`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Insert data into the 'worker' table
INSERT INTO `worker` (`name`, `workname`, `country`, `state`, `city`, `address`, `adharnumber`, `profilephoto`, `contactno`, `email`, `password`, `aboutme`, `createdAt`, `active`) VALUES
('Sundar parmar', 'AC repairing', 'India', 'Karnataka', 'Bengaluru', 'ssss', 321653216547, 'download.jpg', '6058790458', 'sundar@gmail.com', 'Sundar1', 'I am ac mechanic', '2023-10-03 14:35:09', 1),
('ravi joshi', 'car repairing', 'India', 'Gujarat', 'Surat', 'cccc', 9874156321058, 'download.png', '8674897894', 'ravi@gmail.com', 'ravi12', 'I am car mechanic', '2024-10-03 14:37:28', 1),
('Satya kalena', 'bike repairing', 'India', 'Gujarat', 'Ahmedabad', 'dddd', 987456321025, 'download (1).png', '9707859078', 'satya@gmail.com', '123', 'I am bike mechanic', '2023-10-03 14:47:19', 1),
('shivangi sitapara', 'Home cleaning', 'India', 'Gujarat', 'Amreli', 'ffff', 526321563202, 'images (2).png', '5485760347', 'shivangi@gmail.com', 'shivu', 'Toilet Cleaning- Disinfecting, Sanitizing and Deep Scrubbing of Bathrooms and Toilets. Furniture Cleaning- Vacuuming of all sofas, upholstery and curtains', '2024-10-03 14:50:28', 1);

-- Create the 'users' table
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `aadhaarnumber` BIGINT(12) NOT NULL,
  `profilephoto` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `contactno` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Insert data into the 'users' table
INSERT INTO `users` (`firstname`, `lastname`, `email`, `aadhaarnumber`, `profilephoto`, `password`, `address`, `city`, `state`, `contactno`) VALUES
('kuldip', 'parmar', 'kuldip@gmail.com', 987657102321 , '59cd0fd60ae8b.png', '147852', 'manekbag', 'Ahmedabad', 'Gujarat', '7419452194'),
('ram', 'sitapars', 'ram@m.com',  987654321012, '59cd0fd60ae8b.png', '123', 'chital', 'amreli', 'Gujarat', '9876543210'),
('sidhu', 'kalena', 'sidhu@m.com',  132569875632, '59cd0fd60ae8b.png', '321', 'mani nagar', 'surat', 'Gujarat', '7419498794');

-- Create the 'services' table
CREATE TABLE `services` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `servicename` varchar(255) NOT NULL,
  `servicedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `skill` varchar(255) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Insert data into the 'bookings' table
INSERT INTO `services` (`service_id`, `servicename`, `servicedate`, `skill`) VALUES
(001, 'Plumber', '2024-10-10 12:57:04', 'proficient with a wide range of tools, from basic hand tools like wrenches and pipe cutters to more advanced equipment like pipe threaders and drain snakes.'),
(002, 'Electician','2024-08-12 10:05:08', 'Electrical systems knowledge; Circuitry and wiring installation; Troubleshooting and problem-solving; Technical drawing and blueprint reading; Automation and control systems; Safety procedures and protocols; Time management and organization.'),
(003, 'Michenic','2024-10-03 80:40:09', 'the ability to use, repair and maintain machines and tools. to be thorough and pay attention to detail. problem-solving skills.
the ability to work well with your hands. customer service skills. the ability to work well with others. knowledge of engineering science and technology.');


-- Create the 'bookings' table
CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_worker` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `servicedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `notification` varchar(255) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Insert data into the 'bookings' table
INSERT INTO `bookings` (`id_worker`, `id_user`, `service_id`, `servicedate`, `notification`) VALUES
(4, 15, 001, '2024-10-10 12:57:04', NULL),
(2, 14, 002, '2024-08-12 10:05:08', NULL),
(1, 16, 003, '2024-10-03 80:40:09', NULL);

-- Create the 'payments' table
CREATE TABLE `payments` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_method` varchar(255) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_worker` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Insert data into the 'payments' table
INSERT INTO `payments` (`transaction_id`, `payment_method`, `payment_date`, `id_worker`, `id_user`) VALUES
(320, 'card', '2024-10-03 20:07:28', 4, 15),
(321, 'card', '2024-08-12 20:07:28', 2, 14),
(322, 'card', '2024-10-03 20:07:28', 1, 16);

-- Create the 'feedback' table
CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `rating` varchar(5) NOT NULL,
  `message` varchar(255) NOT NULL,
  `id_worker` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Insert data into the 'feedback' table
INSERT INTO `feedback` (`rating`, `message`, `id_worker`, `id_user`) VALUES
('5', 'this person work good', 002, 201),
('3', 'this person work good but it is not time.', 004, 202),
('2', 'this person is not proper work.', 003, 203);

-- Create the 'final_details' table
CREATE TABLE `final_details` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_worker` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`),
  FOREIGN KEY (`id_user`) REFERENCES `users`(`id_user`),
  FOREIGN KEY (`id_worker`) REFERENCES `worker`(`id_worker`),
  FOREIGN KEY (`booking_id`) REFERENCES `bookings`(`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




-- Modify AUTO_INCREMENT for 'admin' table
ALTER TABLE `admin` MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

-- Modify AUTO_INCREMENT for 'worker' table
ALTER TABLE `worker` MODIFY `id_worker` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=001;

-- Modify AUTO_INCREMENT for 'users' table
ALTER TABLE `users` MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

-- Modify AUTO_INCREMENT for 'services' table
ALTER TABLE `services` AUTO_INCREMENT=111;

-- Modify AUTO_INCREMENT for 'bookings' table
ALTER TABLE `bookings` AUTO_INCREMENT=210;

-- Modify AUTO_INCREMENT for 'payments' table
ALTER TABLE `payments` AUTO_INCREMENT=320;

-- Modify AUTO_INCREMENT for 'feedback' table
ALTER TABLE `feedback` AUTO_INCREMENT=3250;

-- Modify AUTO_INCREMENT for 'final_details' table
ALTER TABLE `final_details` AUTO_INCREMENT=500;

ALTER TABLE `users` ADD COLUMN `aadhaarnumber` BIGINT; -- Adjust datatype as needed

ALTER TABLE `worker` ADD COLUMN `adharnumber` VARCHAR(12);


