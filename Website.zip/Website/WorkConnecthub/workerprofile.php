<?php
session_start();

if(empty($_SESSION['id_admin'])) {
  header("Location: index.php");
  exit();
}

require_once("db.php");
$mysqli = new mysqli("localhost", "root", "", "demo1");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>WorkConnecthub</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <link rel="stylesheet" href="css/_all-skins.min.css">
  <!-- Custom -->
  <link rel="stylesheet" href="css/custom.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->
    <a href="index.php" class="logo logo-bg">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>W</b>C</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Work</b> Connecthub</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
         
          <?php if(empty($_SESSION['id_user']) && empty($_SESSION['id_worker'])) { ?>
           
          <?php } else { 

            if(isset($_SESSION['id_user'])) { 
          ?>        
          <li>
            <a href="user/index.php">Dashboard</a>
          </li>
          <?php
          } else if(isset($_SESSION['id_worker'])) { 
          ?>        
          <li>
            <a href="worker/index.php">Dashboard</a>
          </li>
          <?php } ?>
          <li>
            <a href="logout.php">Logout</a>
          </li>
          <?php } ?>          
        </ul>
      </div>
    </nav>
  </header>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="margin-left: 0px;">

 <section id="candidates" class="content-header">
      <div class="container">
        <div class="row">
          <!-- your sidebar content here -->
          <div class="col-md-9 bg-white padding-2">
            <li align="right"><a href="workers.php" ><i class='fa fa-arrow-circle-left'></i> Back</a></li>

            <h3>Selected Worker Details</h3>
            <div class="row margin-top-20">
              <div class="col-md-12">
              <div class="box-body table-responsive no-padding">
    <?php
    $sql = "SELECT name, workname, profilephoto, email, contactno, adharnumber, country, state, city, address, aboutme, createdAt, active FROM worker ORDER BY email LIMIT 1";

    if ($result = $mysqli->query($sql)) {
        if ($row = $result->fetch_assoc()) {
            printf("<div class='form-group'>");
            printf("<label>Profile Photo</label><br>");
            printf("<img src='uploads/profile/%s' height='50px' width='50px'/>", $row['profilephoto']);
            printf("</div>");

            printf("<div class='form-group'>");
            printf("<label>Name :</label>");
            printf("<label>%s</label>", $row['name']);
            printf("</div>");

            printf("<div class='form-group'>");
            printf("<label>Workname : </label>");
            printf("<label>%s</label>", $row['workname']);
            printf("</div>");

            printf("<div class='form-group'>");
            printf("<label>Email : </label>");
            printf("<label>%s</label>", $row['email']);
            printf("</div>");

            printf("<div class='form-group'>");
            printf("<label>contactno : </label>");
            printf("<label>%s</label>", $row['contactno']);
            printf("</div>");

            printf("<div class='form-group'>");
            printf("<label>Adhar Card Number : </label>");
            printf("<label>%s</label>", $row['adharnumber']);
            printf("</div>");

            printf("<div class='form-group'>");
            printf("<label>Addredd : </label>");
            printf("<label>%s</label>", $row['address']);
            printf("</div>");

             printf("<div class='form-group'>");
            printf("<label>city : </label>");
            printf("<label>%s</label>", $row['city']);
            printf("</div>");

             printf("<div class='form-group'>");
            printf("<label>state : </label>");
            printf("<label>%s</label>", $row['state']);
            printf("</div>");

             printf("<div class='form-group'>");
            printf("<label>country : </label>");
            printf("<label>%s</label>", $row['country']);
            printf("</div>");

             printf("<div class='form-group'>");
            printf("<label>aboutme : </label>");
            printf("<label>%s</label>", $row['aboutme']);
            printf("</div>");

             printf("<div class='form-group'>");
            printf("<label>createdAt : </label>");
            printf("<label>%s</label>", $row['createdAt']);
            printf("</div>");

             printf("<div class='form-group'>");
            printf("<label>active : </label>");
            printf("<label>%s</label>", $row['active']);
            printf("</div>");





            // Add similar fields for email, contactno, adharnumber, etc.
        } else {
            echo "No worker found.";
        }
        $result->free();
    }
    $mysqli->close();
    ?>
</div>


            </div>

          </div>
        </div>
      </div>
    </section>

    

  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer" style="margin-left: 0px;">
    <div class="text-center">
      <strong>Copyright &copy; 2024-2025 <a href="dashboard.php">WorkConnecthub</a>.</strong> All rights
    reserved.
    </div>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>

<script type="text/javascript">
  function validatePhone(event) {

    //event.keycode will return unicode for characters and numbers like a, b, c, 5 etc.
    //event.which will return key for mouse events and other events like ctrl alt etc. 
    var key = window.event ? event.keyCode : event.which;

    if(event.keyCode == 8 || event.keyCode == 46 || event.keyCode == 37 || event.keyCode == 39) {
      // 8 means Backspace
      //46 means Delete
      // 37 means left arrow
      // 39 means right arrow
      return true;
    } else if( key < 48 || key > 57 ) {
      // 48-57 is 0-9 numbers on your keyboard.
      return false;
    } else return true;
  }
</script>

<script>
  $("#country").on("change", function() {
    var id = $(this).find(':selected').attr("data-id");
    $("#state").find('option:not(:first)').remove();
    if(id != '') {
      $.post("state.php", {id: id}).done(function(data) {
        $("#state").append(data);
      });
      $('#stateDiv').show();
    } else {
      $('#stateDiv').hide();
      $('#cityDiv').hide();
    }
  });
</script>

<script>
  $("#state").on("change", function() {
    var id = $(this).find(':selected').attr("data-id");
    $("#city").find('option:not(:first)').remove();
    if(id != '') {
      $.post("city.php", {id: id}).done(function(data) {
        $("#city").append(data);
      });
      $('#cityDiv').show();
    } else {
      $('#cityDiv').hide();
    }
  });
</script>
<script>
  $("#registerCompanies").on("submit", function(e) {
    e.preventDefault();
    if( $('#password').val() != $('#cpassword').val() ) {
      $('#passwordError').show();
    } else {
      $(this).unbind('submit').submit();
    }
  });
</script>
</body>
</html>
